export const GlobalEvents = {
    window_resize: 'GlobalEvents_wr',
    main_resize: 'GlobalEvents_mr'
}